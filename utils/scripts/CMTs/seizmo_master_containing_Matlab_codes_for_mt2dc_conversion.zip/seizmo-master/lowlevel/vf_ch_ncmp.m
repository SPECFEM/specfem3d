function [head]=vf_ch_ncmp(varargin)
%VF_CH_NCMP    Sets virtual field NCMP

% there is no ncmp field, do nothing
head=varargin{2};

end