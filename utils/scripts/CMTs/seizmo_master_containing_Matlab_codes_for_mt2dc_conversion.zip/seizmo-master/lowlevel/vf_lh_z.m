function [value]=vf_lh_z(def,head)
%VF_LH_Z    Returns value for virtual field Z as a string

% just pass on to vf_gh_kzdttm
value=vf_gh_kzdttm(def,head);

end
