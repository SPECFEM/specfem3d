function [head]=vf_ch_z6(def,head,value)
%VF_CH_Z6    Sets virtual field Z6

% just pass on to vf_ch_z
head=vf_ch_z(def,head,value);

end
