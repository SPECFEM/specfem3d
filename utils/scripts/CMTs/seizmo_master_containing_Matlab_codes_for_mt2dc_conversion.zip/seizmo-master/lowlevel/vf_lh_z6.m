function [value]=vf_lh_z6(def,head)
%VF_LH_Z6    Returns value for virtual field Z6 as a string

% just pass on to vf_gh_kzdttm
value=vf_gh_kzdttm(def,head);

end
